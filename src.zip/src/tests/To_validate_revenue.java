package tests;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentTest;

public class To_validate_revenue extends BaseClass {

    @Test
    public void To_validate_total_revenue() {
        ExtentTest test = extent.createTest("Validate Total Recurring Reimbursement").assignCategory("Revenue calculator");

        try {
            String slidervalue = ft.slidervalidation();
            Thread.sleep(3000);
            System.out.println("First Test run successfully.....");
            String inputvalue = ft.inputvalidation("560");
            Thread.sleep(3000);
            System.out.println("Second Test run successfully.....");
            String actualoutput = ft.validaterecurringreim("CPT-99091", "CPT-99453", "CPT-99454", "CPT-99474");
            Thread.sleep(3000);
            System.out.println("Third Test run successfully.....");
            String requiredoutput = ft.requiredtotalprice();
            SoftAssert st = new SoftAssert();

            if (slidervalue.equalsIgnoreCase("820")) {
                st.assertTrue(true, "Slider value is correct.");
                test.pass("Slider value validated successfully.");
            } else {
                test.fail("Slider value validation failed.");
            }

            if (inputvalue.equalsIgnoreCase("560")) {
                st.assertTrue(true, "Input value is correct.");
                test.pass("Input value validated successfully.");
            } else {
                test.fail("Input value validation failed.");
            }

            if (actualoutput.equalsIgnoreCase(requiredoutput)) {
                st.assertTrue(true, "Recurring reimbursement is correct.");
                test.pass("Recurring reimbursement validated successfully.");
            } else {
                test.fail("Recurring reimbursement validation failed.");
            }

            st.assertAll();

        } catch (Exception e) {
            e.printStackTrace();
            test.fail("Test execution failed due to exception: " + e.getMessage());
        }
    }
}
