package tests;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import screens.FitPeo_page;
//import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {

    protected WebDriver driver;  // Made driver protected to allow child class access
    protected FitPeo_page ft; // Made ft protected to allow child class access

    public ExtentTest test;
    public static ExtentReports extent;
    public static ExtentSparkReporter spark;

    @BeforeMethod(alwaysRun = true)
    public void driverSetup() {
        try {
            // Initialize ExtentReports
            extent = new ExtentReports();
            spark = new ExtentSparkReporter("Test_Report.html");
            spark.config().setTheme(Theme.DARK);
            spark.config().setDocumentTitle("Test Report");
            spark.config().setReportName("FitPeo_RevenueReport");
            extent.attachReporter(spark);
            
            System.setProperty("webdriver.chrome.driver",
					"C:\\Users\\Nehal.Parmar\\Documents\\Series_of_Selinium\\JIOLocate\\Drivers\\chromedriver_103.exe");

			ChromeOptions options = new ChromeOptions();

			//options.setExperimentalOption("prefs", preferences);

			driver = new ChromeDriver(options);

            // Set up WebDriverManager and initialize WebDriver
          //  WebDriverManager.chromedriver().setup();
//            driver = new ChromeDriver();

            // Set up WebDriver properties
            driver.get("https://www.fitpeo.com/");
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            driver.manage().window().maximize();

            // Initialize Page Object after driver setup
            ft = new FitPeo_page(driver);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @AfterMethod
    public void tearDown() {
        try {
        	extent.flush();
            System.out.println("Closing driver...");
            if (driver != null) {
                driver.quit();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
