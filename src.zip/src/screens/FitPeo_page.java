package screens;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FitPeo_page {

    private WebDriver driver;
    private WebDriverWait wait;
    public Actions action;

    @FindBy(how = How.XPATH, using = "//div[text()='Revenue Calculator']/..")
    WebElement revenuecalculator;

    @FindBy(how = How.XPATH, using = "//span[text()='Patients should be between 0 to 2000']//..//div//input")
    WebElement ptinput;

    @FindBy(how = How.XPATH, using = "//span[@class='MuiSlider-thumb MuiSlider-thumbSizeMedium MuiSlider-thumbColorPrimary MuiSlider-thumb MuiSlider-thumbSizeMedium MuiSlider-thumbColorPrimary css-sy3s50']//input")
    WebElement slider;

    
    public FitPeo_page(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, 30);  // Add explicit wait
        PageFactory.initElements(this.driver, this);
    }

    public String slidervalidation() {
        try {
            action = new Actions(driver);
            wait.until(ExpectedConditions.visibilityOfAllElements(revenuecalculator));

            action.moveToElement(revenuecalculator);
            revenuecalculator.click();
            
            wait.until(ExpectedConditions.visibilityOfAllElements(ptinput));

            JavascriptExecutor js = (JavascriptExecutor) driver;
//            js.executeScript("arguments[0].scrollIntoView(true);", ptinput);
            
            js.executeScript("window.scrollBy(0,150)");
            
            
            wait.until(ExpectedConditions.visibilityOfAllElements(ptinput));
            
           
//            js.executeScript("arguments[0].setAttribute('value', '820');", slider);

            action.clickAndHold(slider)
                    .moveByOffset(94, 0)  // Adjust the offset values as needed (X, Y)
                    .release()
                    .perform();

            // Wait for the slider value to be updated
//            wait.until(ExpectedConditions.attributeToBe(ptinput, "value", "820"));

        

        } catch (Exception e) {
            e.printStackTrace();
           
        }
        return ptinput.getAttribute("value");
    }

    public String inputvalidation(String value) {
        try {
        	Thread.sleep(2000);
        	action.moveToElement(ptinput);
            ptinput.clear();
            
            Thread.sleep(2000);
//            JavascriptExecutor js = (JavascriptExecutor) driver;
//            js.executeScript("arguments[0].setAttribute('value', '0');", slider);
//            action.clickAndHold(slider)
//            .moveByOffset(0, 0)  // Adjust the offset values as needed (X, Y)
//            .release()
//            .perform();
            
            Thread.sleep(1000);
            ptinput.sendKeys(value);
            

            // Wait for the value to be updated
//            wait.until(ExpectedConditions.attributeToBe(slider, "value", String.valueOf(value)));

           

        } catch (Exception e) {
            e.printStackTrace();
            
        }
        return slider.getAttribute("value");
    }

    public String validaterecurringreim(String cpt1, String cpt2, String cpt3, String cpt4) {
        try {
            selectcheckbox(cpt1);
            selectcheckbox(cpt2);
            selectcheckbox(cpt3);
            selectcheckbox(cpt4);

            WebElement totalprice = driver.findElement(By.xpath("//p[text()='Total Recurring Reimbursement for all Patients Per Month:']//p"));
            
            System.out.println(totalprice.getText() +" ============== ");
            return totalprice.getText();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public String requiredtotalprice() {
        try {
            WebElement requiredtotal = driver.findElement(By.xpath("//p[text()='Total Recurring Reimbursement for all Patients Per Month']/..//p[2]"));
            
            System.out.println(requiredtotal.getText() +" ============= ");
            return requiredtotal.getText();

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void selectcheckbox(String cptvalue) {
        try {
            WebElement checkbox = driver.findElement(By.xpath(".//p[text()='" + cptvalue + "']//..//label//input[@type='checkbox']"));
            if (!checkbox.isSelected()) {
                checkbox.click();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
